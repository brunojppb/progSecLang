/*
    PROGRAM: question10.CPP
    Written by Bruno Paulino
    This program calculates the number of miles per gallon the car gets
*/

#include <iostream>
using namespace std;

int main(){
    
    double gallons = 12;
    double miles = 350;

    cout << "QUESTION10:" << endl;
    cout << "Miles per Gallon: " << miles / gallons << endl;

    return 0;
}
