/*
    PROGRAM: question14.CPP
    Written by Bruno Paulino
    This program displays my address
*/

#include <iostream>
using namespace std;

int main(){

    cout << "Bruno de Araujo Paulino\n4020 Millicent cir, Melbourne, FL, 32901\n321 525 5316\nComputer Science" << endl;

    return 0;
}
