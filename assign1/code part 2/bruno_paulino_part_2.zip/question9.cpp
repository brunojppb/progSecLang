/*
    PROGRAM: question9.CPP
    Written by Bruno Paulino
    This program display the amount of memory of int, float, chat and double
*/

#include <iostream>
using namespace std;

int main(){

    cout << "QUESTION9:" << endl;
    cout << "Size of Double:  " << sizeof(double) << " Bites" << endl;
    cout << "Size of Integer: " << sizeof(int) << " Bites" << endl;
    cout << "Size of Float:   " << sizeof(float) << " Bites" << endl;
    cout << "Size of Char:    " << sizeof(char) << " Bite" << endl;
    return 0;
}
