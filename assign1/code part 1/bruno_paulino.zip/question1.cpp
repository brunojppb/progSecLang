/*
    PROGRAM: question1.CPP
    Written by Bruno Paulino
    This program calculates the sum of two numbers
*/

#include <iostream>
using namespace std;

int main(){
    //variables to store the numbers.
    int value1 = 62;
    int value2 = 99;

    //sum of the variables that were declared before.
    int total = value1 + value2;

    cout << "QUESTION 1: " << endl;
    cout << "Total: " << total << endl;

    return 0;
}
