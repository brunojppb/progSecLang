/*
 
 This program demonstrates a simple thread-based menu option.
 The program also calls a function from the boost::filesystem library.
 
 */

#include <iomanip>
#include <boost/thread.hpp>
#include <boost/filesystem.hpp>
#include <iostream>
#include <string>


// Mutual exclusion synchronization primitive to protect agains concurrent updates (i.e., race conditions).
boost::mutex mutex;

// Menu callback functions
void MenuOption1(void);
void MenuOption2(void);
void MenuOption3(void);

// Actual tasks to be performed
void thread_Task1( int tid, std::string name ); // Runs in separate thread
void thread_Task2( int tid, std::string name ); // Runs in separate thread
void Task3(void);


int main()
{
    
    int userOption = 0;
    do {
        std::cout << "1. Run Task 1" << std::endl;
        std::cout << "2. Run Task 2" << std::endl;
        std::cout << "3. Run Task 3" << std::endl;
        std::cout << "0. Exit"       << std::endl;
        
        std::cin >> userOption;
        
        if (1 == userOption)
            MenuOption1();
        else
            if (2 == userOption)
                MenuOption2();
            else
                if (3 == userOption)
                    MenuOption3();
        
    } while ( userOption );
    
    
}

// Callback function
void MenuOption1(void)
{
    // Create a thread to run Task
    boost::thread t1(thread_Task1, 1, "Run Option 1...");
}

// Callback function
void MenuOption2(void)
{
    // Create a thread to run Task
    boost::thread t2(thread_Task2, 2, "Run Option 2...");
}

// Callback function
void MenuOption3(void)
{
    // Run task
    Task3();
}

// Performs task 1
void thread_Task1( int tid, std::string name )
{
    // Perform some time-consuming task
    for (int j = 1; j < tid * 200000000; j++) {
        double h = j / 100;
    }
    
    // Let the user know that task is done. The mutex is protecting
    // the writing of message so other threads don't write their text
    // in the middle of this thread's message.
    mutex.lock();
    std::cout << "Thread " << tid << " "
    << name << ". Done." << std::endl;
    mutex.unlock();
}

// Performs task 2
void thread_Task2( int tid, std::string name )
{
    // Perform some time-consuming task
    for (int j = 1; j < tid * 200000000; j++) {
        double h = j / 100;
    }
    
    // Let the user know that task is done. The mutex is protecting
    // the writing of message so other threads don't write their text
    // in the middle of this thread's message.
    mutex.lock();
    std::cout << "Thread " << tid << " "
    << name << ". Done." << std::endl;
    mutex.unlock();
}

// Performs task 3
void Task3(void)
{
    std::cout << "Run Option 3..." << std::endl;
    
    boost::filesystem::path p("./");
    std::cout << p.string() << std::endl;
    
    std::cout << " Done." <<std::endl;
    
}


