/*
 
 This program demonstrates a simple thread-based menu option.
 The program also calls a function from the boost::filesystem library.
 
 */

#include <iomanip>
#include <boost/thread.hpp>
#include <boost/filesystem.hpp>
#include <iostream>
#include <string>


// Mutual exclusion synchronization primitive to protect agains concurrent updates (i.e., race conditions).
boost::mutex mutex;

// Menu callback functions
void MenuOption1(void);

// Actual tasks to be performed
void thread_Task1( int tid, int startIndex, int endIndex, double *result  );

// Array with sequence of numbers
double A[ ] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };


int main()
{
    
    int userOption = 0;
    do {
        std::cout << "1. Run Task 1" << std::endl;
        std::cout << "0. Exit"       << std::endl;
        
        std::cin >> userOption;
        
        if (1 == userOption)
            MenuOption1();

        
    } while ( userOption );
    
    
}

// Callback function
void MenuOption1(void)
{
    double partial_result1 = 0.0;
    double partial_result2 = 0.0;
    
    // Create two threads calling the same function
    boost::thread t1(thread_Task1, 1, 0, 4, &partial_result1);
    boost::thread t2(thread_Task1, 2, 5, 9, &partial_result2);

    // Wait for the two threads to finish
    t1.join();
    t2.join();
    
    // Display the combined total result of the calculation
    std::cout << std::endl;
    std::cout << "All threads are done. Task completed." << std::endl;
    std::cout << "Result = " << partial_result1 + partial_result2 << std::endl;
    std::cout << std::endl;

}


// Performs task 1
void thread_Task1( int tid, int startIndex, int endIndex, double *result )
{
    // Pretend function is performing some time-consuming task
    sleep(2);
    
    // Sum the values from startIndex to endIndex
    double sum = 0;
    for (int i = startIndex; i <= endIndex; i++)
        sum = sum + A[i];
    
    *result = sum;
    
    // Let the user know that task is done. The mutex lock protects
    // the writing of message so other threads don't write their text
    // in the middle of this thread's message.
    mutex.lock();
        std::cout   << "Thread " << tid << ". Partial = " << *result << std::endl;
    mutex.unlock();
}



