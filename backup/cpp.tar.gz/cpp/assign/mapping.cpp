//
// Compilation instructions:
//  g++ main.cpp -o main
//

#include <iostream>
using namespace std;



int main()
{
    const int NROWS = 3;
    const int NCOLS = 5;
    const int DEPTH = 2;
    
    // Allocate the 3-D volume
    double *A = new double [ NROWS * NCOLS * DEPTH ];
 
    // Populate the 3-D matrix.
    for (int k = 0; k < DEPTH; k++) {
        for (int i = 0; i < NROWS; i++) {
            for (int j = 0; j < NCOLS; j++) {
                // Index calculation
                int index = (long)i * (long)NCOLS * (long)DEPTH + (long)j * (long)DEPTH + (long)k;
                A[ index ] = k;
            }
        }
    }
    
    // Display the planes for each depth
    for (int k = 0; k < DEPTH; k++) {
        for (int i = 0; i < NROWS; i++) {
            for (int j = 0; j < NCOLS; j++) {
                // Index calculation
                int index = (long)i * (long)NCOLS * (long)DEPTH + (long)j * (long)DEPTH + (long)k;
                cout << A[ index ] << "  " ;
            }
            cout << endl;
        }
        cout << endl;
    }
    
    
    return 0;
}
