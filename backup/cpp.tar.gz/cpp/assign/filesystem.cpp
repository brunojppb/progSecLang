#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>
#include <boost/thread.hpp>
#include <boost/filesystem.hpp>
using namespace std;

int main(){
    boost::filesystem::path dir("surprise");

    boost::filesystem::directory_iterator end;
    for ( boost::filesystem::directory_iterator pos(dir); pos != end; ++pos ){
        if ( is_regular_file( *pos ) ){
            std::cout << pos->path().filename() << " : " << boost::filesystem::file_size( pos->path() ) << "\n";
        }
    }   
}