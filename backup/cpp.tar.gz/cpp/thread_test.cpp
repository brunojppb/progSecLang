#include <iostream>
#include <boost/thread.hpp>
using namespace std;

int main(){
    return 0;
}